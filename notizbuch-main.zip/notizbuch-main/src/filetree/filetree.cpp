#include "filetree.hpp"

#include <fstream>
#include <iostream>
int filetree::theme::count = 1;
filetree::singlefile::singlefile(std::string _filepath, std::string _filename,
                                 std::string belong_to_theme) {
  this->filepath = std::filesystem::path(_filepath);
  this->filename = _filename;
  this->belong_to_theme = belong_to_theme;
}
filetree::singlefile::singlefile() {}
std::string filetree::singlefile::getFileName() const { return this->filename; }
std::string filetree::singlefile::readFile() {
  std::ifstream file(this->filepath, std::ios::binary);
  if (!file.is_open()) {
    return "";
  }
  file.seekg(0, std::ios::end);
  std::streamsize fileSize = file.tellg();
  file.seekg(0, std::ios::beg);
  std::string fileContent(fileSize, '\0');
  file.read(&fileContent[0], fileSize);
  file.close();
  return fileContent;
}
filetree::singlefile::~singlefile() {}
filetree::theme::theme(std::string _theme_name) {
  singlefiles.clear();
  uid = this->count;
  this->count = uid + 1;
  this->themename = _theme_name;
}
filetree::theme::~theme() {}
std::string filetree::theme::getThemeName() { return this->themename; }
const std::vector<filetree::singlefile> &filetree::theme::getSonFiles() const {
  return this->singlefiles;
}
bool filetree::theme::addNewFile(std::string _filename) {
  std::string path = workspace.string() + "/" + this->themename + "/";
  if (!std::filesystem::exists(path)) {
    bool okey = std::filesystem::create_directories(path);
    if (!okey)
      return false;
  }
  std::string full_path = path + _filename;
  if (!std::filesystem::exists(full_path)) {
    std::ofstream file(full_path);
    if (!file.is_open())
      return false;
    file.close();
  }
  this->singlefiles.push_back(
      filetree::singlefile(path + _filename, _filename, this->themename));
  return true;
};
std::string filetree::singlefile::getFilePath() const {
  return (this->filepath).string();
}
bool filetree::createFile(std::string filename, std::string themename) {
  std::string path = workspace.string() + "/" + themename + "/";
  if (!std::filesystem::exists(path)) {
    bool okey = std::filesystem::create_directories(path);
    if (!okey)
      return false;
  }
  std::string full_path = path + filename + ".md";
  if (!std::filesystem::exists(full_path)) {
    std::ofstream file(full_path);
    if (!file.is_open())
      return false;
    file.close();
  }
  return true;
};
std::vector<filetree::theme> filetree::loadFile() {
  std::vector<filetree::theme> themes;
  for (const auto &entry : std::filesystem::directory_iterator(workspace)) {
    if (entry.is_directory()) {
      themes.push_back((entry.path().filename().string()));
      for (const auto &file :
           std::filesystem::directory_iterator(entry.path())) {
        if (file.is_regular_file() && file.path().extension() == ".md") {
          themes[themes.size() - 1].addNewFile(file.path().filename().string());
        }
      }
    }
  }
  return themes;
}