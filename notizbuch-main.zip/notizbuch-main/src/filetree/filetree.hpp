#pragma once
#include <filesystem>
#include <string>
#include <vector>
namespace filetree {
static std::filesystem::path workspace = "./note";
class singlefile {
private:
  std::filesystem::path filepath = "";
  std::string filename;
  std::string belong_to_theme = "";

public:
  singlefile(std::string _filepath, std::string _filename,
             std::string belong_to_theme_uid);
  std::string getFileName() const;
  std::string getFilePath() const;
  std::string readFile();
  explicit singlefile();
  ~singlefile();
};

class theme {
private:
  unsigned int uid = 0;
  std::string themename;
  std::vector<singlefile> singlefiles;
  static int count;

public:
  theme(std::string _theme_name);
  std::string getThemeName();
  const std::vector<singlefile> &getSonFiles() const;
  bool addNewFile(std::string _filename);
  ~theme();
};
bool createFile(std::string filename, std::string theme);
std::vector<filetree::theme> loadFile();
} // namespace filetree
