#include "UI.h"
#include "editor/editor.hpp"
#include "filetree/filetree.hpp"
#include "imgui.h"
#include "imgui_internal.h"
#include "preview/preview.hpp"
#include <iostream>
#include <queue>
#include <string>
#include <vector>

namespace UI {

void RenderUI() {

  static bool opt_fullscreen = true;
  static bool opt_padding = false;
  static filetree::singlefile nowFile;
  bool pdf = false;

  // static std::queue<GLuint> texture_queue; // 渲染图片使用队列以防爆内存
  // static const int max_queue_size =
  //     2; // 限制队伍的长度<=2 ,保留前一帧，释放前前帧

  static ImGuiDockNodeFlags dockspace_flags = ImGuiDockNodeFlags_None;
  ImGuiWindowFlags window_flags =
      ImGuiWindowFlags_MenuBar | ImGuiWindowFlags_NoDocking;
  if (opt_fullscreen) {
    const ImGuiViewport *viewport = ImGui::GetMainViewport();
    ImGui::SetNextWindowPos(viewport->WorkPos);
    ImGui::SetNextWindowSize(viewport->WorkSize);
    ImGui::SetNextWindowViewport(viewport->ID);
    ImGui::PushStyleVar(ImGuiStyleVar_WindowRounding, 0.0f);
    ImGui::PushStyleVar(ImGuiStyleVar_WindowBorderSize, 0.0f);
    window_flags |= ImGuiWindowFlags_NoTitleBar | ImGuiWindowFlags_NoCollapse |
                    ImGuiWindowFlags_NoResize | ImGuiWindowFlags_NoMove;
    window_flags |=
        ImGuiWindowFlags_NoBringToFrontOnFocus | ImGuiWindowFlags_NoNavFocus;
  } else {
    dockspace_flags &= ~ImGuiDockNodeFlags_PassthruCentralNode;
  }
  if (dockspace_flags & ImGuiDockNodeFlags_PassthruCentralNode)
    window_flags |= ImGuiWindowFlags_NoBackground;
  if (!opt_padding)
    ImGui::PushStyleVar(ImGuiStyleVar_WindowPadding, ImVec2(0.0f, 0.0f));
  ImGui::Begin("DockSpace Demo", nullptr, window_flags);
  if (!opt_padding)
    ImGui::PopStyleVar();

  if (opt_fullscreen)
    ImGui::PopStyleVar(2);

  // Submit the DockSpace
  ImGuiIO &io = ImGui::GetIO();
  if (io.ConfigFlags & ImGuiConfigFlags_DockingEnable) {
    ImGuiID dockspace_id = ImGui::GetID("MyDockSpace");
    ImGui::DockSpace(dockspace_id, ImVec2(0.0f, 0.0f), dockspace_flags);
  }

  // ImGui::ShowDemoWindow();
  if (ImGui::BeginMenuBar()) {
    if (ImGui::BeginMenu("Options")) {
      ImGui::MenuItem("pdf", NULL, &pdf);
      if (pdf)
        preview::genPDF(std::filesystem::path(nowFile.getFilePath()));
      ImGui::EndMenu();
    }
    ImGui::EndMenuBar();
  }
  ImGui::End();
  ImGui::Begin(" ");
  ImVec2 contentRegion = ImGui::GetContentRegionAvail();
  float totalWidth = contentRegion.x;
  float width1 = totalWidth * 2.0f / 10.0f; // 20%
  float width2 = totalWidth * 4.0f / 10.0f; // 40%
  float width3 = totalWidth * 4.0f / 10.0f; // 40%
  ImGui::BeginChild("filesystem", ImVec2(width1, contentRegion.y), true);
  static std::vector<filetree::theme> themes = filetree::loadFile();
  // folder        +  UI
  ImGui::PushFont(g_Fonts.strong_font);
  ImGui::Text("Folder");
  ImGui::SameLine();
  float button_width = 30;
  ImGuiStyle &style = ImGui::GetStyle();
  ImVec4 original_button_col = style.Colors[ImGuiCol_Button];
  ImVec4 original_button_hover_col = style.Colors[ImGuiCol_ButtonHovered];
  ImVec4 original_button_active_col = style.Colors[ImGuiCol_ButtonActive];
  ImVec4 original_text_col = style.Colors[ImGuiCol_Text];

  ImGui::SetCursorPosX(ImGui::GetWindowWidth() - button_width - 10);
  style.Colors[ImGuiCol_Button] = ImVec4(0.0f, 0.0f, 0.0f, 0.0f);
  style.Colors[ImGuiCol_ButtonHovered] = ImVec4(0.0f, 0.0f, 0.0f, 0.0f);
  style.Colors[ImGuiCol_ButtonActive] = ImVec4(0.0f, 0.0f, 0.0f, 0.0f);
  style.Colors[ImGuiCol_Text] = ImVec4(0.0f, 0.0f, 1.0f, 1.0f);
  if (ImGui::Button("+", ImVec2(button_width, button_width))) {
    ImGui::OpenPopup("ADD");
  }
  style.Colors[ImGuiCol_Button] = original_button_col;
  style.Colors[ImGuiCol_ButtonHovered] = original_button_hover_col;
  style.Colors[ImGuiCol_ButtonActive] = original_button_active_col;
  style.Colors[ImGuiCol_Text] = original_text_col;
  ImGui::PopFont();
  static char filename[2048] = "";
  static char theme[2048] = "";
  if (ImGui::BeginPopupModal("ADD", NULL)) {
    ImGui::InputText("FileName", filename, IM_ARRAYSIZE(filename));
    ImGui::InputText("Theme", theme, IM_ARRAYSIZE(theme));
    ImGui::SetCursorPosX(ImGui::GetWindowWidth() -
                         ImGui::CalcTextSize("Close Create         ").x);
    if (ImGui::Button("Close")) {
      ImGui::CloseCurrentPopup();
    }
    ImGui::SameLine();
    if (ImGui::Button("Create")) {
      filetree::createFile(filename, theme);
      themes = filetree::loadFile();
      ImGui::CloseCurrentPopup();
    }
    ImGui::EndPopup();
  }
  // 渲染文件树
  static int selectedThemeIndex = -1;
  static int selectedFileIndex = -1;
  for (size_t i = 0; i < themes.size(); i++) {
    if (ImGui::CollapsingHeader(themes[i].getThemeName().c_str())) {
      for (size_t j = 0; j < themes[i].getSonFiles().size(); j++) {
        auto &file = themes[i].getSonFiles()[j];
        bool is_selected = (selectedThemeIndex == static_cast<int>(i) &&
                            selectedFileIndex == static_cast<int>(j));
        ImGui::PushID(file.getFilePath().c_str());

        if (is_selected) {
          ImGui::PushStyleColor(ImGuiCol_Header,
                                ImVec4(0.94f, 1.0f, 0.94f, 1.0f));
          ImGui::PushStyleColor(ImGuiCol_HeaderHovered,
                                ImVec4(0.6f, 0.7f, 0.9f, 1.0f));
        }
        if (ImGui::Selectable(("   " + file.getFileName()).c_str(),
                              is_selected)) {
          selectedThemeIndex = static_cast<int>(i);
          selectedFileIndex = static_cast<int>(j);
          nowFile = file;
        }
        if (is_selected) {
          ImGui::PopStyleColor(2);
        }
        ImGui::PopID();
      }
    }
  }
  ImGui::EndChild();
  ImGui::SameLine();
  ImGui::BeginChild("editor", ImVec2(width2, contentRegion.y), true);
  static char text_buffer[4096 * 4] = "";
  auto tmp = nowFile.readFile();
  std::copy(tmp.begin(), tmp.end(), text_buffer);
  text_buffer[tmp.size()] = '\0';
  ImVec2 window_size = ImGui::GetWindowSize();
  float text_area_width = width2; // 窗口宽度的90%
  float text_area_height = (window_size.y / ImGui::GetTextLineHeight()) *
                               ImGui::GetTextLineHeight() -
                           30; // 20行高度
  auto ret = ImGui::InputTextMultiline(
      "text editor", text_buffer, IM_ARRAYSIZE(text_buffer),
      ImVec2(text_area_width, text_area_height));
  // if (io.KeyCtrl && ImGui::IsKeyPressed(ImGuiKey_S)) {
  if (ret) {
    std::string text(text_buffer);
    editor::save(nowFile.getFilePath(), text);
    // preview::genPDF(nowFile.getFilePath());
    // preview::genPNG(nowFile.getFilePath());
  }
  // ImGui::Text("file:\n%s", nowFile.getFileName().c_str());
  // ImGui::Text("file:\n%s", nowFile.readFile().c_str());
  // ImGui::Text("You typed:\n%s", text_buffer);
  ImGui::EndChild();
  // auto filepath = std::filesystem::path(nowFile.getFilePath());
  // std::filesystem::path PNGFilePath =
  //     filepath.parent_path() / (filepath.stem().string() + ".png");
  // GLuint new_texture = 0;
  // int new_width = 0, new_height = 0;
  // if (preview::LoadTextureFromFile(PNGFilePath.string().c_str(),
  // &new_texture,
  //                                  &new_width, &new_height)) {
  //   texture_queue.push(new_texture);
  //   if (texture_queue.size() > max_queue_size) {
  //     GLuint oldest_texture = texture_queue.front();
  //     texture_queue.pop();
  //     glDeleteTextures(1, &oldest_texture);
  //   }
  // }

  // ImGui::Begin("PDFRender");
  // if (PNGFilePath.string() != ".png") {
  //   if (!texture_queue.empty()) {
  //     GLuint current_texture = texture_queue.back();
  //     ImGui::Image((ImTextureID)(intptr_t)current_texture,
  //                  ImVec2(new_width, new_height));
  //   }
  // }
  ImGui::SameLine();
  ImGui::BeginChild("OwnRender", ImVec2(width3, contentRegion.y), true);

  preview::nowLINE = 0, preview::nowPos = 0;
  preview::RenderMarkdown(std::string(text_buffer));
  ImGui::EndChild();
  ImGui::End();
}
} // namespace UI