#pragma once

#include "../filetree/filetree.hpp"
#include "../utils/stb/stb_image.hpp"
#include "glew.h"
#include "imgui.h"
#include "imgui/imgui_internal.h"
#include "utils/stb/stb_image.hpp"
#include <cmark.h>
#include <filesystem>
#include <iostream>
#include <queue>
#include <unordered_map>
namespace preview {
bool genHTML(std::filesystem::path filepath);
bool genPDF(std::filesystem::path filepath);
bool genPNG(std::filesystem::path filepath);
std::string genXML(std::string mktext);
bool LoadTextureFromMemory(const void *data, size_t data_size,
                           GLuint *out_texture, int *out_width,
                           int *out_height);
bool LoadTextureFromFile(const char *file_name, GLuint *out_texture,
                         int *out_width, int *out_height);
struct FontsCollection {
  ImFont *normal_font;
  ImFont *emphasis_font;
  ImFont *strong_font;
  ImFont *h1_font;
  ImFont *h2_font;
  ImFont *h3_font;
  ImFont *h4_font;
  ImFont *h5_font;
  ImFont *h6_font;
};
void InitializeFonts(ImGuiIO &io);
void RenderMarkdown(const std::string &markdown);
static int nowLINE = 60; // 当前行数
static int nowPos = 0;   // 当前行的水平位置（像素）
// 辅助函数：递归渲染 Markdown 节点到 ImGui 窗口
struct TextureInfo {
  GLuint texture_id;
  int width;
  int height;
};
void RenderMarkdownNode(cmark_node *node, int level, int heading, int indent);
static std::unordered_map<std::string, TextureInfo> texture_cache;
bool LoadTextureWithCache(const std::string &path, GLuint *out_texture,
                          int *out_width, int *out_height);
} // namespace preview
extern preview::FontsCollection g_Fonts;
