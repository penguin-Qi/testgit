
#include "./preview.hpp"
preview::FontsCollection g_Fonts;

void preview::InitializeFonts(ImGuiIO &io) {
  g_Fonts.normal_font = io.Fonts->AddFontFromFileTTF(
      "Hack-Regular.ttf", 25.0f, nullptr, io.Fonts->GetGlyphRangesJapanese());
  g_Fonts.emphasis_font =
      io.Fonts->AddFontFromFileTTF("Hack-BoldItalic.ttf", 25.0f, nullptr,
                                   io.Fonts->GetGlyphRangesJapanese());
  g_Fonts.strong_font = io.Fonts->AddFontFromFileTTF(
      "Hack-Bold.ttf", 25.0f, nullptr, io.Fonts->GetGlyphRangesJapanese());
  g_Fonts.h1_font = io.Fonts->AddFontFromFileTTF(
      "Hack-Bold.ttf", 60.0f, nullptr, io.Fonts->GetGlyphRangesJapanese());
  g_Fonts.h2_font = io.Fonts->AddFontFromFileTTF(
      "Hack-Bold.ttf", 50.0f, nullptr, io.Fonts->GetGlyphRangesJapanese());
  g_Fonts.h3_font = io.Fonts->AddFontFromFileTTF(
      "Hack-Bold.ttf", 40.0f, nullptr, io.Fonts->GetGlyphRangesJapanese());
  g_Fonts.h4_font = io.Fonts->AddFontFromFileTTF(
      "Hack-Bold.ttf", 35.0f, nullptr, io.Fonts->GetGlyphRangesJapanese());
  g_Fonts.h5_font = io.Fonts->AddFontFromFileTTF(
      "Hack-Bold.ttf", 30.0f, nullptr, io.Fonts->GetGlyphRangesJapanese());
  g_Fonts.h6_font = io.Fonts->AddFontFromFileTTF(
      "Hack-Bold.ttf", 28.0f, nullptr, io.Fonts->GetGlyphRangesJapanese());
} // Simple helper function to load an image into a OpenGL texture with common
// settings
bool preview::genHTML(std::filesystem::path filepath) {
  if (filepath.empty())
    return false;
  std::filesystem::path outputFilePath =
      filepath.parent_path() / (filepath.stem().string() + ".html");

  // 构建 Pandoc 命令
  std::string command = "pandoc \"" + filepath.string() + "\"  -o \"" +
                        outputFilePath.string() + "\"";
  // std::cout << command << std::endl;
  // std::string command = "pandoc ./note/1/hello.md -o  ./1.html";
  auto ret = system(command.c_str());
  return ret;
}
bool preview::genPDF(std::filesystem::path filepath) {
  if (filepath.empty())
    return false;
  std::filesystem::path outputFilePath =
      filepath.parent_path() / (filepath.stem().string() + ".pdf");

  // 构建 Pandoc 命令
  std::string command = "pandoc \"" + filepath.string() +
                        "\" --pdf-engine=wkhtmltopdf --quiet -o \"" +
                        outputFilePath.string() + "\"";
  // std::cout << command << std::endl;
  // std::string command = "pandoc ./note/1/hello.md -o  ./1.html";
  auto ret = system(command.c_str());
  return ret;
}
bool preview::genPNG(std::filesystem::path filepath) {
  if (filepath.empty())
    return false;
  std::filesystem::path inputPath =
      filepath.parent_path() / (filepath.stem().string() + ".pdf");
  std::filesystem::path outputFilePath =
      filepath.parent_path() / (filepath.stem().string());

  // 构建 pdftoppm 命令
  std::string command = "pdftoppm -singlefile -f 1 -png -r 120 \"" +
                        inputPath.string() + "\" \"" + outputFilePath.string() +
                        "\"";
  std::cout << command << "\n";
  auto ret = system(command.c_str());
  return ret;
}
std::string preview::genXML(std::string mktext) {
  const char *markdown_cstr = mktext.c_str();
  size_t markdown_len = mktext.size();
  cmark_node *document =
      cmark_parse_document(markdown_cstr, markdown_len, CMARK_OPT_DEFAULT);
  char *xml = cmark_render_xml(document, CMARK_OPT_DEFAULT);
  auto res = std::string(xml);
  free(xml);
  cmark_node_free(document);
  return res;
}
bool preview::LoadTextureFromMemory(const void *data, size_t data_size,
                                    GLuint *out_texture, int *out_width,
                                    int *out_height) {
  // Load from file
  int image_width = 0;
  int image_height = 0;
  unsigned char *image_data =
      stbi_load_from_memory((const unsigned char *)data, (int)data_size,
                            &image_width, &image_height, NULL, 4);
  if (image_data == NULL)
    return false;

  // Create a OpenGL texture identifier
  GLuint image_texture;
  glGenTextures(1, &image_texture);
  glBindTexture(GL_TEXTURE_2D, image_texture);

  // Setup filtering parameters for display
  glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
  glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);

  // Upload pixels into texture
  glPixelStorei(GL_UNPACK_ROW_LENGTH, 0);
  glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA, image_width, image_height, 0, GL_RGBA,
               GL_UNSIGNED_BYTE, image_data);
  stbi_image_free(image_data);

  *out_texture = image_texture;
  *out_width = image_width;
  *out_height = image_height;

  return true;
}

// Open and read a file, then forward to LoadTextureFromMemory()
bool preview::LoadTextureFromFile(const char *file_name, GLuint *out_texture,
                                  int *out_width, int *out_height) {
  FILE *f = fopen(file_name, "rb");
  if (f == NULL)
    return false;
  fseek(f, 0, SEEK_END);
  size_t file_size = (size_t)ftell(f);
  if (file_size == -1)
    return false;
  fseek(f, 0, SEEK_SET);
  void *file_data = IM_ALLOC(file_size);
  fread(file_data, 1, file_size, f);
  fclose(f);
  bool ret = LoadTextureFromMemory(file_data, file_size, out_texture, out_width,
                                   out_height);
  IM_FREE(file_data);
  return ret;
}
bool preview::LoadTextureWithCache(const std::string &path, GLuint *out_texture,
                                   int *out_width, int *out_height) {
  if (texture_cache.find(path) != texture_cache.end()) {
    *out_texture = texture_cache[path].texture_id;
    *out_width = texture_cache[path].width;
    *out_height = texture_cache[path].height;
    return true;
  }
  if (LoadTextureFromFile(path.c_str(), out_texture, out_width, out_height)) {
    texture_cache[path].texture_id = *out_texture;
    texture_cache[path].width = *out_width;
    texture_cache[path].height = *out_height;
    return true;
  }
  return false;
}
void preview::RenderMarkdownNode(cmark_node *node, int level = 0,
                                 int heading = 0, int indent = 0) {
  if (node == nullptr)
    return;
  cmark_node_type node_type = cmark_node_get_type(node);
  const char *text = cmark_node_get_literal(node);
  ImVec2 space_size = ImGui::CalcTextSize("   ");
  ImVec2 indent_size = ImGui::CalcTextSize("  ");

  switch (node_type) {
  case CMARK_NODE_DOCUMENT:
    nowPos = space_size.x;
    nowLINE = 30;
    for (cmark_node *child = cmark_node_first_child(node); child != nullptr;
         child = cmark_node_next(child)) {
      RenderMarkdownNode(child, level);
    }
    break;

  case CMARK_NODE_PARAGRAPH:
    for (cmark_node *child = cmark_node_first_child(node); child != nullptr;
         child = cmark_node_next(child)) {
      RenderMarkdownNode(child, level, heading, indent);
    }
    nowLINE += 30;         // 段落结束，换行
    nowPos = space_size.x; // 重置水平位置
    break;

  case CMARK_NODE_HEADING: {
    nowPos = space_size.x; // 重置水平位置
    auto level = cmark_node_get_heading_level(node);
    if (level == 1)
      ImGui::PushFont(g_Fonts.h1_font);
    else if (level == 2)
      ImGui::PushFont(g_Fonts.h2_font);
    else if (level == 3)
      ImGui::PushFont(g_Fonts.h3_font);
    else if (level == 4)
      ImGui::PushFont(g_Fonts.h4_font);
    else if (level == 5)
      ImGui::PushFont(g_Fonts.h5_font);
    else if (level == 6)
      ImGui::PushFont(g_Fonts.h6_font);
    for (cmark_node *child = cmark_node_first_child(node); child != nullptr;
         child = cmark_node_next(child)) {
      RenderMarkdownNode(child, level, heading = level);
    }
    if (level == 1 || level == 2 || level == 3)
      nowLINE += 60;
    else if (level == 4 || level == 5)
      nowLINE += 35;
    else if (level == 6)
      nowLINE += 30;
    nowPos = space_size.x; // 重置水平位置
    ImGui::PopFont();
  } break;

  case CMARK_NODE_TEXT: {
    if (heading == 0) {
      if (text) {
        for (size_t i = 0; text[i] != '\0'; ++i) {
          char letter = text[i];
          ImVec2 letter_size = ImGui::CalcTextSize(&letter, &letter + 1);
          if (nowPos + letter_size.x >
              ImGui::GetWindowContentRegionMax().x - space_size.x) {
            nowLINE += 30;                                  // 换行
            nowPos = space_size.x + indent * indent_size.x; // 重置水平位置
          }
          ImGui::SetCursorPos(ImVec2(nowPos, nowLINE));
          ImGui::Text("%c", letter);
          nowPos += letter_size.x;
        }
      }
    } else if (heading == 1 || heading == 2 || heading == 3) {
      if (text) {
        for (size_t i = 0; text[i] != '\0'; ++i) {
          char letter = text[i];
          ImVec2 letter_size = ImGui::CalcTextSize(&letter, &letter + 1);
          if (nowPos + letter_size.x >
              ImGui::GetWindowContentRegionMax().x - space_size.x + 40) {
            nowLINE += 60;              // 换行
            nowPos = space_size.x - 40; // 重置水平位置
          }
          ImGui::SetCursorPos(ImVec2(nowPos, nowLINE));
          ImGui::Text("%c", letter);
          nowPos += letter_size.x;
        }
      }
    } else if (heading == 4 || heading == 5) {
      if (text) {
        for (size_t i = 0; text[i] != '\0'; ++i) {
          char letter = text[i];
          ImVec2 letter_size = ImGui::CalcTextSize(&letter, &letter + 1);
          if (nowPos + letter_size.x >
              ImGui::GetWindowContentRegionMax().x - space_size.x + 40) {
            nowLINE += 35;              // 换行
            nowPos = space_size.x - 40; // 重置水平位置
          }
          ImGui::SetCursorPos(ImVec2(nowPos, nowLINE));
          ImGui::Text("%c", letter);
          nowPos += letter_size.x;
        }
      }
    } else {
      if (text) {
        for (size_t i = 0; text[i] != '\0'; ++i) {
          char letter = text[i];
          ImVec2 letter_size = ImGui::CalcTextSize(&letter, &letter + 1);
          if (nowPos + letter_size.x >
              ImGui::GetWindowContentRegionMax().x - space_size.x + 40) {
            nowLINE += 30;              // 换行
            nowPos = space_size.x - 40; // 重置水平位置
          }
          ImGui::SetCursorPos(ImVec2(nowPos, nowLINE));
          ImGui::Text("%c", letter);
          nowPos += letter_size.x;
        }
      }
    }
  } break;

  case CMARK_NODE_EMPH: {
    ImGui::PushFont(g_Fonts.emphasis_font); // 使用强调文本的字体
    for (cmark_node *child = cmark_node_first_child(node); child != nullptr;
         child = cmark_node_next(child)) {
      RenderMarkdownNode(child, level);
    }
    ImGui::PopFont();
  } break;

  case CMARK_NODE_STRONG: {
    ImGui::PushFont(g_Fonts.strong_font); // 使用强调文本的字体
    for (cmark_node *child = cmark_node_first_child(node); child != nullptr;
         child = cmark_node_next(child)) {
      RenderMarkdownNode(child, level);
    }
    ImGui::PopFont();
  } break;

  case CMARK_NODE_CODE: {
    nowLINE += 30;
    nowPos = space_size.x;
    if (text) {
      for (size_t i = 0; text[i] != '\0'; ++i) {
        char letter = text[i];
        ImVec2 letter_size = ImGui::CalcTextSize(&letter, &letter + 1);
        if (nowPos + letter_size.x >
            ImGui::GetWindowContentRegionMax().x - space_size.x) {
          nowLINE += 30;         // 换行
          nowPos = space_size.x; // 重置水平位置
        }
        ImGui::SetCursorPos(ImVec2(nowPos, nowLINE));
        ImGui::TextColored(ImVec4(0.5f, 0.5f, 0.5f, 1.0f), "%c", letter);
        nowPos += letter_size.x;
      }
    }
  } break;
  case CMARK_NODE_LIST: {
    // nowLINE++;
    nowPos = space_size.x;
    for (cmark_node *child = cmark_node_first_child(node); child != nullptr;
         child = cmark_node_next(child)) {
      RenderMarkdownNode(child, level);
    }
  } break;
  case CMARK_NODE_ITEM: {
    ImGui::PushFont(g_Fonts.strong_font); // 使用强调文本的字体

    text = "- ";
    if (text) {
      for (size_t i = 0; text[i] != '\0'; ++i) {
        char letter = text[i];
        ImVec2 letter_size = ImGui::CalcTextSize(&letter, &letter + 1);
        if (nowPos + letter_size.x >
            ImGui::GetWindowContentRegionMax().x - space_size.x) {
          nowLINE += 30;         // 换行
          nowPos = space_size.x; // 重置水平位置
        }
        ImGui::SetCursorPos(ImVec2(nowPos, nowLINE));
        ImGui::Text("%c", letter);
        nowPos += letter_size.x;
      }
    }
    ImGui::PopFont();

    for (cmark_node *child = cmark_node_first_child(node); child != nullptr;
         child = cmark_node_next(child)) {
      RenderMarkdownNode(child, level, heading, indent + 1);
    }
  } break;
  case CMARK_NODE_IMAGE: {
    auto nowx = ImGui::GetWindowSize().x;
    auto path = cmark_node_get_url(node);
    nowLINE += 20;
    int my_image_width = 0;
    int my_image_height = 0;
    GLuint my_image_texture = 0;
    bool ret = LoadTextureWithCache(path, &my_image_texture, &my_image_width,
                                    &my_image_height);
    ImGui::SetCursorPos(ImVec2(nowx / 2 - my_image_width / 2, nowLINE));
    ImGui::Image((ImTextureID)(intptr_t)my_image_texture,
                 ImVec2(my_image_width, my_image_height));
    nowLINE += my_image_height;
    // nowLINE += 20;
    nowPos = space_size.x;
  } break;
  case CMARK_NODE_LINK: {
    auto label = cmark_node_get_literal(cmark_node_first_child(node));
    auto url = cmark_node_get_url(node);
    if (url == NULL)
      url = label;
    static bool isClick = false; // 用于记录是否点击到文本区域
    ImVec2 mouse_pos = ImGui::GetIO().MousePos; // 获取当前鼠标位置
    bool mouse_clicked = ImGui::IsMouseClicked(0); // 检测鼠标左键是否点击
    ImGui::PushStyleColor(ImGuiCol_Text, ImVec4(0.0f, 0.0f, 1.0f, 1.0f));
    if (label) {
      for (size_t i = 0; label[i] != '\0'; ++i) {
        char letter = label[i];
        ImVec2 letter_size = ImGui::CalcTextSize(&letter, &letter + 1);

        // 检查是否需要换行
        if (nowPos + letter_size.x >
            ImGui::GetWindowContentRegionMax().x - space_size.x) {
          nowLINE += 30;         // 换行
          nowPos = space_size.x; // 重置水平位置
        }

        // 设置当前字符的光标位置
        ImGui::SetCursorPos(ImVec2(nowPos, nowLINE));

        // 计算当前字符的包围盒
        ImVec2 char_pos = ImGui::GetCursorScreenPos();
        ImRect char_bb(char_pos, {(char_pos.x + letter_size.x),
                                  (char_pos.y + letter_size.y)});

        // 渲染字符
        ImGui::Text("%c", letter);

        // 检测鼠标点击
        if (mouse_clicked && char_bb.Contains(mouse_pos)) {
          isClick = true; // 如果鼠标点击在字符区域内，设置 isClick 为 true
        }

        // 更新水平位置
        nowPos += letter_size.x;
      }
    }
    ImGui::PopStyleColor();
    ImGuiContext &g = *GImGui;
    if (isClick) {
      if (g.PlatformIO.Platform_OpenInShellFn != NULL)
        g.PlatformIO.Platform_OpenInShellFn(&g, url);
      isClick = !isClick;
    }
  } break;
  case CMARK_NODE_THEMATIC_BREAK: {
    nowLINE += 10;
    ImU32 line_color = IM_COL32(0, 1, 0, 255);
    ImGuiWindow *const window = ImGui::GetCurrentWindow();
    ImDrawList *const draw = ImGui::GetWindowDrawList();
    float scrollY = ImGui::GetScrollY();

    ImVec2 st(window->Pos.x + space_size.x,
              window->Pos.y + window->DC.CurrLineTextBaseOffset - scrollY +
                  nowLINE);
    ImVec2 ed(
        window->Pos.x + ImGui::GetWindowContentRegionMax().x - space_size.x,
        window->Pos.y + window->DC.CurrLineTextBaseOffset - scrollY + nowLINE);

    ImDrawList *draw_list = ImGui::GetWindowDrawList();
    draw_list->AddLine(st, ed, line_color,
                       2.0f); // 绘制直线，线宽为 2.0
    nowLINE += 30;
    nowPos = space_size.x;
  } break;
  case CMARK_NODE_SOFTBREAK:
    text = " ";
    if (heading == 0) {

      if (text) {
        for (size_t i = 0; text[i] != '\0'; ++i) {
          char letter = text[i];
          ImVec2 letter_size = ImGui::CalcTextSize(&letter, &letter + 1);
          if (nowPos + letter_size.x >
              ImGui::GetWindowContentRegionMax().x - space_size.x) {
            nowLINE += 30;                                  // 换行
            nowPos = space_size.x + indent * indent_size.x; // 重置水平位置
          }
          ImGui::SetCursorPos(ImVec2(nowPos, nowLINE));
          ImGui::Text("%c", letter);
          nowPos += letter_size.x;
        }
      }
    } else if (heading == 1 || heading == 2 || heading == 3) {
      if (text) {
        for (size_t i = 0; text[i] != '\0'; ++i) {
          char letter = text[i];
          ImVec2 letter_size = ImGui::CalcTextSize(&letter, &letter + 1);
          if (nowPos + letter_size.x >
              ImGui::GetWindowContentRegionMax().x - space_size.x + 40) {
            nowLINE += 60;              // 换行
            nowPos = space_size.x - 40; // 重置水平位置
          }
          ImGui::SetCursorPos(ImVec2(nowPos, nowLINE));
          ImGui::Text("%c", letter);
          nowPos += letter_size.x;
        }
      }
    } else if (heading == 4 || heading == 5) {
      if (text) {
        for (size_t i = 0; text[i] != '\0'; ++i) {
          char letter = text[i];
          ImVec2 letter_size = ImGui::CalcTextSize(&letter, &letter + 1);
          if (nowPos + letter_size.x >
              ImGui::GetWindowContentRegionMax().x - space_size.x + 40) {
            nowLINE += 35;              // 换行
            nowPos = space_size.x - 40; // 重置水平位置
          }
          ImGui::SetCursorPos(ImVec2(nowPos, nowLINE));
          ImGui::Text("%c", letter);
          nowPos += letter_size.x;
        }
      }
    } else {
      if (text) {
        for (size_t i = 0; text[i] != '\0'; ++i) {
          char letter = text[i];
          ImVec2 letter_size = ImGui::CalcTextSize(&letter, &letter + 1);
          if (nowPos + letter_size.x >
              ImGui::GetWindowContentRegionMax().x - space_size.x + 40) {
            nowLINE += 30;              // 换行
            nowPos = space_size.x - 40; // 重置水平位置
          }
          ImGui::SetCursorPos(ImVec2(nowPos, nowLINE));
          ImGui::Text("%c", letter);
          nowPos += letter_size.x;
        }
      }
    }
    break;
  case CMARK_NODE_LINEBREAK:
    nowLINE += 30;
    nowPos = space_size.x;
    break;
  default:
    ImGui::Text("Unknown node type: %s", cmark_node_get_type_string(node));
    // std::cout << cmark_node_get_type_string(node);
    break;
  }
}
void preview::RenderMarkdown(const std::string &markdown) {
  cmark_node *document = cmark_parse_document(markdown.c_str(), markdown.size(),
                                              CMARK_OPT_DEFAULT);

  // 渲染到 ImGui 窗口
  RenderMarkdownNode(document);

  // 清理资源
  cmark_node_free(document);
}