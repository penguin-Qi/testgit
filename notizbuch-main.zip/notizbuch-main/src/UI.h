#pragma once
namespace UI {
void RenderUI();
}