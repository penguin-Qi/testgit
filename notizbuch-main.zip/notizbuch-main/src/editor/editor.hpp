#pragma once
#include <filesystem>
#include <fstream>
namespace editor {
void save(std::string filepath, std::string text);
} // namespace editor
