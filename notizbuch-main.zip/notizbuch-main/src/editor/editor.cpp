#include "editor.hpp"
void editor::save(std::string filepath, std::string text) {
  std::ofstream file(filepath);
  if (!file.is_open())
    return;
  file << text;
  file.close();
}
